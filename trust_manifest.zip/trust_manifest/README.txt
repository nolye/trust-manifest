# VPN Killer

Monitors your VPN. If it disconnects, it kills your network adapters instantly.

> Use with caution. Designed for Windows 10+.

How to use:
1. Install Python 3: https://www.python.org/downloads/
2. Open PowerShell and run:
   pip install psutil
   python vpn_killer.py
