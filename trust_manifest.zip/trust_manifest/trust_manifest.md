# trust_manifest

They own the banks.  
They own the platforms.  
They own the rules.

But they don’t own this file.  
They don’t own my voice.  
They don’t own what I build.

This script kills your internet if your VPN dies.  
Because trust isn't a promise — it's a kill switch.

Tips welcome, but not required:
monero:
8BZDY12cK2GPQcxt6fZGBv9LgT9LQmUFujYquBVSDmRyeHiqY7y5Xsj4NNJasmR8Fd9iQfnhaiLjF6iHb3x71BqB5SNFPTf
